const twitterClientId = 'bHFwcDRKczB4WGhWeGNNZUY5aGw6MTpjaQ'
const twitterClientSecret = '-RNYe0qzZpa8gSoxrl7tu-RTV5HjoiuRTnG6EDXuZzrDqWggr5'
const basicAuthorizationHeader =
  'Basic ' + btoa(`${twitterClientId}:${twitterClientSecret}`)
const replicateApiToken = '5b1ad04992986ff64e5ec5e86650607c2b7e7990'
const replicateModelVersion =
  '3554d9e699e09693d3fa334a79c58be9a405dd021d3e11281256d53185868912'
const replicateWebHook =
  'https://1nt5t83lva.execute-api.us-west-2.amazonaws.com/test/helloworld'
const twitterUserId = '1582172223896289281'
const twitterOauthToken = '1371894777592037383-rlJodLgdKGe4UtDpQj5SSqwi1gvoiq'
const twitterOauthTokenSecret = 'ASHpOcOPWOWmCg6VJnUlA7covU3wSJRniuw8BviFB9TBD'
const twitterOauthConsumerKey = 'YpFyvnPL1FGmutE8U7F3x80dA'
const twitterOauthConsumerSecret =
  'sn45dri4153wHP56PNElmJzi0GjL8mxVHUbrGqTSb2iqibg79y'

const TwitterSecrets = {
  clientId: twitterClientId,
  clientSecret: twitterClientSecret,
  basicAuthorizationHeader: basicAuthorizationHeader,
  userId: twitterUserId,
  oauthToken: twitterOauthToken,
  oauthTokenSecret: twitterOauthTokenSecret,
  oauthConsumerKey: twitterOauthConsumerKey,
  oauthConsumerSecret: twitterOauthConsumerSecret,
}

const ReplicateSecrets = {
  apiToken: replicateApiToken,
  modelVersion: replicateModelVersion,
  webhookUrl: replicateWebHook,
}

module.exports = { TwitterSecrets, ReplicateSecrets }
